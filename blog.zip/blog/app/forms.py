from flask_wtf import FlaskForm
from flask_wtf.file import FileAllowed,FileField,FileRequired
from wtforms import SubmitField,StringField,PasswordField,BooleanField,TextAreaField
from wtforms.validators import Length,EqualTo,Email,DataRequired,ValidationError
from app.models import User
from flask import request
from app.extensions import photos
from werkzeug.security import generate_password_hash,check_password_hash

user = User()
class RegisterForm(FlaskForm):
    username = StringField('用户名',validators=[Length(3.10,message='用户名必须在3-10个字符之间')])
    password_hash = PasswordField('密码',validators=[Length(6,12,message='密码长度必须3-10个字符之间')])
    confirm = PasswordField('确认密码',validators=[EqualTo('password',message='两次密码不一致')])
    email = StringField('邮箱',validators=[Email(message='邮箱格式不正确')])
    submit = SubmitField('立即注册')

 

    #书写字段效验的函数：username、email
    def validate_username(self,field):
        user = User.query.filter(User.username==field.data).first()
        if user:
            raise ValidationError('用户名已存在,请选用其他用户名注册')
    def validate_email(self,field):
        user = User.query.filter(User.email == field.data).first()
        if user:
            raise ValidationError('该邮箱已注册，请选用其他邮箱')


class LoginForm(FlaskForm):
    username = StringField('用户名',validators=[DataRequired(message='用户名不能为空')])
    password = StringField('密码',validators=[DataRequired(message='密码不能为空')])
    remember = BooleanField('是否记住',default=False)
    submit = SubmitField('立即登录')


#上传图像表单
class UploadForm(FlaskForm):
    photo = FileField('头像',validators=[FileRequired('选择文件'),FileAllowed(photos,message='只能是图片')])
    submit = SubmitField('确认更改')


#发表博客的表单
class PostsForm(FlaskForm):
    content = TextAreaField(render_kw={'placeholder':'这一刻的想法……'},validators=[Length(3,128,message='内容范围3-128个字符')])
    submit = SubmitField('立即发表')





