from flask import Blueprint, jsonify
from flask_login import current_user


posts = Blueprint('posts', __name__)


@posts.route('/publish/')
def publish():
    return '发表博客'


# 接收并处理ajax请求
@posts.route('/collect/<int:pid>/')
def collect(pid):
    # 判断是否已经收藏该博客
    if current_user.is_favorite(pid):
        # 已经收藏，取消收藏
        current_user.del_favorite(pid)
        status = '收藏'
    else:
        # 没有收藏，添加收藏
        current_user.add_favorite(pid)
        status = '取消收藏'
    # 返回按钮上应该显示的内容
    return jsonify({'status': status})
