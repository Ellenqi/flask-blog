# 导入类库
from flask import Blueprint, render_template, current_app, flash, redirect, url_for, request
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from werkzeug.security import generate_password_hash, check_password_hash
from app.forms import PostsForm
from app.models import Posts
from app.extensions import db
from flask_login import current_user


# 创建蓝本
main = Blueprint('main', __name__)


# 添加视图函数
@main.route('/', methods=['GET', 'POST'])
def index():
    form = PostsForm()
    if form.validate_on_submit():
        if not current_user.is_authenticated:
            flash('登录后才可发表')
            return redirect(url_for('user.login'))
        u = current_user._get_current_object()
        p = Posts(content=form.content.data, user=u)
        db.session.add(p)
        flash('发表成功')
        return redirect(url_for('main.index'))
    # 读取所有发表博客数据
    # posts = Posts.query.filter(Posts.rid == 0).order_by(Posts.timestamp.desc()).all()
    # 分页查询发表博客数据
    # 获取当前页码
    page = request.args.get('page', 1, int)
    pagination = Posts.query.filter(Posts.rid == 0).order_by(Posts.timestamp.desc()).paginate(page=page, per_page=4, error_out=False)
    posts = pagination.items
    return render_template('main/index.html', form=form, posts=posts, pagination=pagination)


# 生成token
@main.route('/generate/')
def generate():
    s = Serializer(current_app.config['SECRET_KEY'], expires_in=3600)
    token = s.dumps({'id': 250})
    return token


# 校验token
@main.route('/check/<token>')
def check(token):
    s = Serializer(current_app.config['SECRET_KEY'])
    data = s.loads(token)
    return str(data['id'])


@main.route('/jiami/')
def jiami():
    return generate_password_hash('123456')


@main.route('/jiaoyan/<password>/')
def jiaoyan(password):
    if check_password_hash('pbkdf2:sha256:50000$bO5cz5Av$f6193a356d3d1c576744d61348451a73b410755e135936eee8745c51fae2d9eb', password):
        return '密码正确'
    return '密码错误'